$(document).ready(function () {
  $("form").submit(function () {
    // your code here (build up your url)
    event.preventDefault();
    let city = document.getElementById("city").value;

    //declare a variable that just has the key stored
    let url = "http://api.openweathermap.org/data/2.5/weather?q=";
    const key = "&appid=264f130b6b9bc6bc72dc00a88be397fe";
    //add the search to the key store variable
    url += city + key;
    console.log(url);
    // make the API call with the variable
    $.get(url, function (resp) {
      // store the information that is needed
      console.log(resp);
      temp = Math.floor(1.8 * (resp.main.temp - 273) + 32);
      let infoString = ""
      infoString += `
        <h1>${resp.name}:</h1>
        <h3>Current Temperature (F): ${temp} degrees</h3>
      `
      //display the info in the info-display div
      $('.info-display').html(infoString);
      // your code here
    },
      "json"
    );
    // don't forget to return false so the page doesn't refresh
    return false;
  });
});
